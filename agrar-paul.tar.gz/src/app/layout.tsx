import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Landwirtschaftsbetrieb Paul - Landwirtschaftliche Dienstleistungen',
  description: 'Professionelle landwirtschaftliche Dienstleistungen, Transport und Winterdienst. John Deere Traktor, Pflanzenschutz, Düngung, Bodenbearbeitung und mehr.',
  keywords: 'Landwirtschaft, Traktor, Pflanzenschutz, Düngung, Transport, Winterdienst, John Deere, landwirtschaftliche Dienstleistungen',
  authors: [{ name: 'Landwirtschaftsbetrieb Paul' }],
  robots: 'index, follow',
  openGraph: {
    title: 'Landwirtschaftsbetrieb Paul - Landwirtschaftliche Dienstleistungen',
    description: 'Professionelle landwirtschaftliche Dienstleistungen, Transport und Winterdienst mit modernen Maschinen.',
    type: 'website',
    locale: 'de_DE',
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="scroll-smooth">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
